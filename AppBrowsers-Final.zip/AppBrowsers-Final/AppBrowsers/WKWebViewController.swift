//
//  WKWebViewController.swift
//  AppBrowsers
//
//  Created by Ampy 2 on 3/26/16.
//  Copyright © 2016 AF. All rights reserved.
//

import Foundation
import UIKit
import WebKit

class WKWebViewController: UIViewController {
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var progressIndicator: UIProgressView!
    @IBOutlet weak var backButton: UIBarButtonItem!
    @IBOutlet weak var forwardButton: UIBarButtonItem!
    
    var reloadCancelButton : UIBarButtonItem?
    var urlString : String?
    
    var webview : WKWebView
    
    required init?(coder aDecoder: NSCoder) {
        
        // User Script
        // This will apply a background color on the document body
        let source = "document.body.style.background = \"#CDB5CD\";"
        let userScript = WKUserScript(source: source, injectionTime: .AtDocumentEnd, forMainFrameOnly: true)
        
        // User Content Controller
        let userContentController = WKUserContentController()
        userContentController.addUserScript(userScript)
        
        // Configuration
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = userContentController
        self.webview = WKWebView(frame: CGRectZero, configuration: configuration)

        super.init(coder: aDecoder)
        webview.navigationDelegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // "Done" button to dismiss
        self.enableCustomBackButtom()
        
        // Reload/Cancel
        reloadCancelButton = UIBarButtonItem(image: UIImage(named: "icon_refresh"), style: .Plain, target: self, action: #selector(WKWebViewController.tappedReloadCancelButton))
        navigationItem.setRightBarButtonItem(reloadCancelButton, animated: false)

        // Add webview as a subview
        view.insertSubview(webview, belowSubview: progressIndicator)
        
        // Adjust constraints
        webview.translatesAutoresizingMaskIntoConstraints = false
        let heightConstraint = NSLayoutConstraint(item: webview, attribute: .Height, relatedBy: .Equal, toItem: view, attribute: .Height, multiplier: 1, constant: -44)
        let widthConstraint = NSLayoutConstraint(item: webview, attribute: .Width, relatedBy: .Equal, toItem: view, attribute: .Width, multiplier: 1, constant: 0)
        view.addConstraints([heightConstraint, widthConstraint])
        
        // Load the URL
        if let urlString = urlString {
            webview.loadRequest(NSURLRequest(URL: NSURL(string: urlString)!))
        }
        
        webview.allowsBackForwardNavigationGestures = true // viewDidLoad


        // Initial state of controls
        progressIndicator.setProgress(0.0, animated: false)
        backButton.enabled = false
        forwardButton.enabled = false
        
        // Observe these properties to set the value of UI controls
        webview.addObserver(self, forKeyPath: "loading", options: .New, context: nil)
        webview.addObserver(self, forKeyPath: "estimatedProgress", options: .New, context: nil)
    }
    

    deinit {
        // Always remove observers in deinit to prevent crash
        webview.removeObserver(self, forKeyPath: "loading")
        webview.removeObserver(self, forKeyPath: "estimatedProgress")
    }
    
    
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<()>) {
        if (keyPath == "loading") {
            backButton.enabled = webview.canGoBack
            forwardButton.enabled = webview.canGoForward
            
            // Toggles the image on the reload/cancel button
            reloadCancelButton!.image = webview.loading ? UIImage(named: "icon_stop") : UIImage(named: "icon_refresh")
            UIApplication.sharedApplication().networkActivityIndicatorVisible = webview.loading
            
            // Puts the URL of the page on the title text field
            if (webview.loading == false) {
                titleTextField.text = webview.URL?.absoluteString
            }
        } else if (keyPath == "estimatedProgress") {
            progressIndicator.hidden = webview.estimatedProgress == 1
            progressIndicator.setProgress(Float(webview.estimatedProgress), animated: true)
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    
    
    @IBAction func tappedBackButton(sender: AnyObject) {
        webview.goBack()
    }
    
    @IBAction func tappedForwardButton(sender: AnyObject) {
        webview.goForward()
    }
    
    
    func tappedReloadCancelButton() -> () {
        if webview.loading {
            webview.stopLoading()
        } else {
            let request = NSURLRequest(URL: webview.URL!)
            webview.loadRequest(request)
        }
    }
    
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        // This adjusts the frame of the textfield on the navigation bar when we rotate the device
        titleTextField.frame = CGRect(x:0, y: 0, width: size.width, height: 30)
    }
    
    

}


extension WKWebViewController : WKNavigationDelegate {
    
    func webView(webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: NSError) {
        // Handle errors here. Example: AppTransportSecurity when using http to load a page
        let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .Alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .Default, handler: nil))
        presentViewController(alert, animated: true, completion: nil)
    }
    
    func webView(webView: WKWebView, decidePolicyForNavigationAction navigationAction: WKNavigationAction, decisionHandler: (WKNavigationActionPolicy) -> Void) {
        
        // Any website other than those from meetup.com will be opened in Safari
        // You might do this if this is a dedicated app to your company's website
        if navigationAction.navigationType == .LinkActivated && !(navigationAction.request.URL?.host?.lowercaseString.containsString("meetup.com"))! {
            UIApplication.sharedApplication().openURL(navigationAction.request.URL!)
            decisionHandler(.Cancel)
        } else {
            decisionHandler(.Allow)
        }
    }

    
}

extension UIViewController: UIGestureRecognizerDelegate {
    func didTapDone() {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func enableCustomBackButtom() {
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Done", style: .Plain, target: self, action: #selector(UIViewController.didTapDone))

        // Do this so you don't break the swipe to go back gesture when customizing back button
        self.navigationController?.interactivePopGestureRecognizer!.delegate = self
    }
}
