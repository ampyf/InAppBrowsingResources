### ContentBlocker ###

===========================================================================
DESCRIPTION:

This is an empty application. The item of interest is the 
ContentBlockerFilter folder.
The blockerList.json contains the triggers (website or css element)
and the corresponding action (block, or in case of css, hide)

See the blog tutorial link in the slides for more details on how to
activate Safari content blockers

===========================================================================